async function fetchPosts() {
  const loader = document.getElementById("loader");
  const loaderText = document.getElementById("loader-text");
  const postsGrid = document.getElementById("posts");

  // Show loader
  loader.removeAttribute("hidden");
  loaderText.removeAttribute("hidden");
  postsGrid.setAttribute("hidden", "");

  const api = "https://shivjhawebtech.online/wp-json/wp/v2/posts?_embed&per_page=12";

  try {
    const res = await fetch(api);
    if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
    const posts = await res.json();
    renderPosts(posts);
  } catch (err) {
    console.error("Error fetching posts:", err);
    postsGrid.innerHTML = `<p style=\"color:red\">Failed to load posts. Please try again later.</p>`;
  } finally {
    // Hide loader regardless of success/error
    loader.setAttribute("hidden", "");
    loaderText.setAttribute("hidden", "");
    postsGrid.removeAttribute("hidden");
  }
}

function stripHTML(html) {
  const div = document.createElement("div");
  div.innerHTML = html;
  return div.textContent || div.innerText || "";
}

function renderPosts(posts) {
  const postsGrid = document.getElementById("posts");
  const fragment = document.createDocumentFragment();

  posts.forEach((post) => {
    const title = stripHTML(post.title.rendered);
    const excerpt = stripHTML(post.excerpt.rendered).slice(0, 140) + "...";

    let imageUrl = "https://via.placeholder.com/640x360?text=No+Image";
    if (
      post._embedded &&
      post._embedded["wp:featuredmedia"] &&
      post._embedded["wp:featuredmedia"][0]
    ) {
      imageUrl = post._embedded["wp:featuredmedia"][0].source_url;
    }

    const card = document.createElement("article");
    card.className = "card";
    card.innerHTML = `
      <img src="${imageUrl}" alt="${title}" loading="lazy" />
      <div class="card-content">
        <h2 class="card-title">${title}</h2>
        <p class="card-excerpt">${excerpt}</p>
        <a class="card-link" href="${post.link}" target="_blank" rel="noopener">Read more</a>
      </div>`;
    fragment.appendChild(card);
  });

  postsGrid.innerHTML = "";
  postsGrid.appendChild(fragment);
}

document.addEventListener("DOMContentLoaded", fetchPosts);
